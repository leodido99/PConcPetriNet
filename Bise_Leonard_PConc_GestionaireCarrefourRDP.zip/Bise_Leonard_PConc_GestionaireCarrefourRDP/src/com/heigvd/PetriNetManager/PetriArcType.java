package com.heigvd.PetriNetManager;

/**
 * Created by leonard.bise on 18.04.18.
 */
public enum PetriArcType {
    SIMPLE, TEST, INHIBIT
}
